var app = angular.module('realty_app', ['ui.slider', 'ngAnimate']);

app.factory('colorpicker', function () {
  function hexFromRGB(r, g, b) {
    var hex = [r.toString(16), g.toString(16), b.toString(16)];

    angular.forEach(hex, function(value, key) {
    if (value.length === 1)
      hex[key] = "0" + value;
    });
    return hex.join('').toUpperCase();
  }

  return {
    refreshSwatch: function(r, g, b) {
      var color = '#' + hexFromRGB(r, g, b);
      angular.element('#swatch').css('background-color', color);
    }
  };

});

app.controller('sliderDemoCtrl', function ($scope, $log, colorpicker) {
  function refreshSwatch(ev, ui) {
    var red = $scope.colorpicker.red,
        green = $scope.colorpicker.green,
        blue = $scope.colorpicker.blue;

    colorpicker.refreshSwatch(red, green, blue);
  }
  // Slider options with event handlers
  $scope.slider = {
    'options': {
      start: function (event, ui) {
        $log.info('Event: Slider start - set with slider options', event);
      },
      stop: function (event, ui) {
        $log.info('Event: Slider stop - set with slider options', event);
      }
    }
  };


  $scope.colorpicker = {
    red: 255,
    green: 140,
    blue: 60,
    options: {
      orientation: 'horizontal',
      min: 0,
      max: 255,
      range: 'min',
      change: refreshSwatch,
      slide: refreshSwatch
    }
  };
});

app.controller('main', function ($scope, $http) {
  // Объект с главной информацией
  $scope.mainObj = {
    header: {
      slogan: 'АГЕНТСТВО ЭЛИТНОЙ НЕДВИЖИМОСТИ В АСТАНЕ',
      number: 'Заказать звонок',
      menu1: 'Главная',
      menu2: 'Клиенты',
      menu3: 'Каталог',
      menu4: 'Рекомендации',
      menu5: 'Сервис',
      menu6: 'Сотрудничество',
      menu7: 'Бонусы',
      menu8: 'Контакты'
    },
    mainPage: {
      mainButton: 'ПОСМОТРИТЕ ВИДЕО',
      header: 'Я хочу',
      button1: 'Купить',
      button2: 'Арендовать',
      button3: 'Продать',
      button4: 'Сдать'
    },
    specPage: {
      header: 'СПЕЦПРЕДЛОЖЕНИЯ',
      arend: 'Аренда',
      sale: 'Продажа',
      floor: 'Комнаты',
      square: 'Площадь',
      price: 'Цена',
      more: 'Подробнее'
    },
    clientPage: {
      header: 'Наши клиенты',
    },
    catalogPage: {
      header: 'Каталог квартир',
      menu1_1: 'Купить',
      menu1_2: 'Снять в аренду',
      menu1_3: 'Все',
      menu2_1: 'Квартиру',
      menu2_2: 'Дом',
      menu2_3: 'Офис',
      menu2_4: 'Земельный участок',
      menu3_1: 'Любой комнатности',
      menu3_2: '1-а комнатные',
      menu3_3: '2-х комнатные',
      menu3_4: '3-х комнатные',
      search: 'Найдено',
      search_content: 'объекта недвижимости',
      search_content_none: 'ничего не найдено',
      from: 'от',
      to: 'до'
    },
    qualityPage: {
      header: 'Преимущества',
      icons1: {
        header: 'Мультиязычные менеджеры',
        content: 'Английский, немецкий, японский язык'
      }, 
      icons2: {
        header: 'База квартир',
        content: 'Более 5000 вариантов в базе квартир'
      }, 
      icons3: {
        header: 'Help-line',
        content: 'Англоговорящий администратор Информация о любых товарах и услугах г.Астаны'
      }, 
      icons4: {
        header: 'Юридическая чистота',
        content: '— Скрининг документов ',
        content2: '— Полный пакет документов'
      }, 
      icons5: {
        header: 'Ознакомительные программы',
        content: '— Знакомство с городом',
        content2: '— Культурные и социальные экскурсии'
      }, 
      icons6: {
        header: 'Сервис служба',
        content: '— Решение бытовых проблем',
        content2: '— Оплата ком.услуг',
        content3: '— Решение правовых вопросов с арендаторами'
      }, 
    },
    recomendPage: {
      header: 'Рекомендации',
      header_director: 'Обращение директора',
      header_clients: 'Отзывы клиентов',
      main_content_part1: 'С помощью',
      main_content_part2: 'более 30 посольств и иностранных компаний нашли уютный и безопасный дом в Астане для своих сотрудников.',
      content: 'Разнообразный и богатый опыт начало повседневной работы по формированию позиции в значительной степени обуславливает создание системы обучения кадров, соответствует насущным потребностям. Идейные соображения высшего порядка, а также укрепление и развитие структуры требуют от нас анализа направлений прогрессивного развития. Задача организации, в особенности же постоянный количественный рост и сфера нашей активности позволяет оценить значение соответствующий условий активизации.Значимость этих проблем настолько очевидна, что рамки и место обучения кадров позволяет оценить значение модели развития.'
    },
    servicePage: {
      header: 'Сервис',
      subHeader: 'Техническая поддержка компании',
      listHeader: 'У нас есть инструменты, навыки, и время для тех случайных работ которые Вы планировали сделать.',
      listElem1: 'Малярные работы',
      listElem2: 'Сантехнические работы',
      listElem3: 'Услуги плотника',
      listElem4: 'Услуги электрика',
      listElem5: 'Химчистка ковров и мягкой мебели',
      listElem6: 'Оплата ком. услуг',
      listElem7: 'Устранение плесени',
      listElem8: 'Замена лампочек',
      listElem9: 'Ремонт бытовой техники',
      listElem10: 'Ремонт окон',
      listElem11: 'Услуги садовника',
      listElem12: 'Сборка мебели',
      listElem13: 'Установка и настройка интернета',
      listElem14: 'Установка и ремонт спутникового ТВ',
      listElem15: 'Установка ролл-штор',
      sloganTop: 'Не бывает неважной работы.',
      sloganBot: 'Позвоните что бы получить бесплатную смету.',
      wordSlogan1: 'Восстановить.',
      wordSlogan2: 'Построить.',
      wordSlogan3: 'Починить.',
    },
    sotrPage: {
      header: 'Сотрудничество',
      subHeader: 'О компании',
      content1: 'Не следует, однако забывать, что постоянный количественный рост и сфера нашей активности представляет собой интересный эксперимент проверки форм развития.',
      content2: 'Значимость этих проблем настолько очевидна, что консультация с широким активом играет важную роль в формировании новых предложений',
      content3: 'Равным образом дальнейшее развитие различных форм деятельности представляет собой интересный эксперимент проверки систем массового участия.',
      planeHeader1: 'УЗНАЙ СКОЛЬКО СТОИТ ТВОЯ КВАРТИРА ',
      planeHeader2: 'БЕСПЛАТНО',
      planeHeader3: 'И',
      planeHeader4: 'БЫСТРО',
      button: 'УЗНАТЬ СТОИМОСТЬ',
    },
    bonus: {
      header: 'Бонусы',
      content1: '— Мы готовы предоставить вам любую полезную информацию, касающуюся проживания в г.Астана и Казахстане.',
      content2: '— Правовая, экономическая и информационная помощь для наших клиентов.',
      button1: 'ПОЛУЧИТЬ',
      button2: 'БОНУС!'
    },
    contacts: {
      adress1: 'Астана',
      adress2: 'Макетный проспект, 23 A',
      button: 'Написать нам' 
    },
    form: {
      headers: {
        header1: 'Получить бесплатную',
        header2: 'консультацию',
        header3: 'ОСТАВИТЬ ЗАЯВКУ',
        header4: 'Получить бонус'
      },
      placeholders: {
        name: 'Имя',
        password: 'Пароль',
        mail: 'Email',
        send: 'Отправить',
        comment: 'Комментарий',
        telephone: 'Телефон',
        feed: 'Все ваши данные в безопасности',
        login: 'Логин',
        sname: 'Фамилия',
        register: 'Регистрация'
      }
    },
    modal : {
      manager: ' Менеджер',
    }
  };
  // Массив объектов для раздела спец предложения
  $scope.spec = [1,2,3,4];

  // Иконки в партнерах
  $scope.partner = [1,2,3,4,5,6,7,8];

  // Массив объектов для каталога квартир, каждый объект отдельная квартира
  $scope.catalog_search = [];

  // Запрос на файл квартир
  $http.get('floors.json')
    .then(function (value) {
       $scope.catalog_search = value.data;

       var maxS = [],
            maxP = [];

       for (var i = 0; i < value.data.length; i++) {
         maxS[i] = value.data[i].square;
         maxP[i] = value.data[i].price;
       };

       $scope.sliderExample9[1] = Math.max.apply(null, maxS);
       $scope.sliderMax = Math.max.apply(null, maxS);
       $scope.price[1] = Math.max.apply(null, maxP);
    }); 

  // Переменные для отображения в меню квартир, обрезаются в функции changeValueFilter если больше 7 символов
  $scope.dropDown1FilterView = 'Все';
  $scope.dropDown2FilterView = 'Все';
  $scope.dropDown3FilterView = 'Любой комнатности';

  // Переменный для фильтрации квартир
  $scope.dropDown1Filter = 'Все';
  $scope.dropDown2Filter = 'Все';
  $scope.dropDown3Filter = 'Все';

  $scope.sliderMax = '';
  $scope.sliderExample9 = [0, $scope.sliderMax];
  $scope.sliderValues = [0, $scope.sliderMax];

  $scope.price = [0];

  // TODO { сделать запрос на сервер с постом и узнать курс доллара }
  $scope.coef = {
    active: 1,
    coef_dol: 350,
    cur: 'тг'

  };
  
  // Модальное окно авторизации
  $scope.auth = {
    show: false,
    close: function () {
      $scope.auth.show = false;
    },
  };

  // Провека языка
  $scope.lang = {
    language: localStorage.getItem('language'), 
    show: false,
    close: function () {
      $scope.lang.show = false;
    },
  };

  $scope.info = {
    show: false,
    name: 'Квартал «Новая земля»',
    floor: '3',
    square: '75',
    price: '25000000',
    content: 'Квартал «Новая Земля» это 6 монолитных корпусов переменной этажности 17-22. Отделка наружных стен - вентилируемые фасады с облицовкой керамогранитом. Витражное остекление балконов и лоджий, панорамное остекление верхних этажей, качественная отделка входных групп. ',
    thumbnail: 'http://farm2.staticflickr.com/1617/24108587812_6c9825d0da_b.jpg',
    images: [
      'http://farm4.staticflickr.com/3691/10185053775_701272da37_b.jpg',
      'http://farm1.staticflickr.com/574/22407305427_69cc6e845f_b.jpg',
      'http://farm1.staticflickr.com/291/18653638823_a86b58523c_b.jpg',
    ],
    author: {
      name: 'Имя Фамилия',
      telephone: 'Телефон',
      email: 'test@mail.ru',
      image: 'img/manager.jpeg',
    },
    change: function (index, show) {
      var _object = $scope.catalog_search[index];

      this.name = _object.name;
      this.floor = _object.floor;
      this.square = _object.square;
      this.price = _object.price;
      this.content = _object.content;
      this.thumbnail = _object.thumbnail;
      this.images = _object.images;
      this.author = _object.author;

      if (show) this.show = true;

    },
    close: function () {
      $scope.info.show = false;
    },
  };

  $scope.feedback = {
    show: false,
    header: $scope.mainObj.form.headers.header3,
    close: function () {
      this.show = false;
    },
    open: function (head) {
      this.show = true;
      this.header = head;
    }
  };
  // value - фильтр который меняет значение dropdowns
  $scope.changeValueFilter = function (value, dropDown) {
    switch (dropDown){

      case 1: 
        if (value.length < 7) {
          $scope.dropDown1FilterView = value;
          $scope.dropDown1Filter = value;
        } else {
          $scope.dropDown1FilterView = value.slice(0,5)+ '..';
          $scope.dropDown1Filter = value;
        }  
        break;

      case 2: 
        if (value.length < 7) {
          $scope.dropDown2FilterView = value;
          $scope.dropDown2Filter = value;
        } else {
          $scope.dropDown2FilterView = value.slice(0,6)+ '..';
          $scope.dropDown2Filter = value;
        }  
        break;

      case 3: 
        if (value === 'Все') {
          $scope.dropDown3FilterView = 'Любой комнатности';
          $scope.dropDown3Filter = value;
        } else {
          $scope.dropDown3FilterView = value;
          $scope.dropDown3Filter = value[0];
          console.log(value[0]);
        }
        break;

      default:  
        $scope.dropDown1FilterView = 'Все';
        $scope.dropDown2FilterView = 'Все';
        $scope.dropDown3FilterView = 'Любой комнатности';
        $scope.dropDown1Filter = 'Все';
        $scope.dropDown2Filter = 'Все';
        $scope.dropDown3Filter = 'Любой комнатности';
        break; 
    }     
  }

  $scope.typeView = function (elem) {
    if ($scope.dropDown1Filter === 'Все') return true;

    if ($scope.dropDown1Filter === elem.type_sale) return true;

    return false;
  }

  $scope.type = function (elem) {
    if ($scope.dropDown2Filter === 'Все') return true;

    if ($scope.dropDown2Filter === elem.type) return true;

    return false;
  }

  $scope.quantityRoom = function (elem) {
    if ($scope.dropDown3Filter === 'Все') return true;

    if ($scope.dropDown3Filter === elem.floor.toString()) return true;

    return false;
  } 

  $scope.squareRange = function (elem) {
    $scope.sliderValues[0] = document.querySelector('#sliderFrom').value;
    $scope.sliderValues[1] = document.querySelector('#sliderTo').value;
    if (elem.square >= $scope.sliderValues[0] && elem.square <= $scope.sliderValues[1]) return true;
    return false;
  }  

  $scope.priceRange = function (elem) {
    if (elem.price >= $scope.price[0] && elem.price <= $scope.price[1]) return true;
    return false;
  } 

  $scope.coefChange = function (elemId, coef, cur) {
    document.querySelector('#catalog .configure .price .val.active').classList.remove('active');
    document.querySelector(elemId).classList.add('active');
    $scope.coef.active = coef;
    $scope.coef.cur = cur;
  }

  // переключатель для языков в меню 
  var changeLangIcon = function (argum) {
    if (argum === 'rus'){
      document.querySelector('.lang_wrap .ru').classList.add('active');
      document.querySelector('.lang_wrap .en').classList.remove('active'); 
    } else if (argum === 'eng') {
      document.querySelector('.lang_wrap .en').classList.add('active'); 
      document.querySelector('.lang_wrap .ru').classList.remove('active');
    }  
  };

  $scope.lang.setLang = function (arg) {
    if(arg === 'rus') {
        // формируем русский объект
        $http.get('lang/ru.json')
          .then(function (value) {
            $scope.mainObj = value.data;
            //console.log(JSON.stringify($scope.mainObj));
          });

        $scope.lang.show = false;
        window.localStorage.setItem('language', 'rus');
        changeLangIcon(arg);
    } else if (arg === 'eng') {
        // формируем английский объект
        $http.get('lang/en.json')
          .then(function (value) {
            $scope.mainObj = value.data;
            //console.log(JSON.stringify($scope.mainObj));
          });

        $scope.lang.show = false;
        window.localStorage.setItem('language', 'eng');
        changeLangIcon(arg);
    }
  };

  if ($scope.lang.language) {
    $scope.lang.setLang($scope.lang.language);
  } else {
    $scope.lang.show = true;
  }

});
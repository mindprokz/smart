<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="ru"> <!--<![endif]-->
<!-- html manifest="app.cache" -->
<head>

	<meta charset="utf-8">

	<title>Заголовок</title>
	<meta name="description" content="">
	<meta name="Keywords" content="">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link rel="shortcut icon" href="img/favicon/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" href="img/favicon/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-touch-icon-114x114.png">

	<link rel="stylesheet" href="css/style.min.css">
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="bower_components/fancybox/source/jquery.fancybox.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.js"></script>
	<script src="https://code.angularjs.org/1.5.0/angular-animate.min.js"></script>
	<script src="js/controller.js"></script>
</head>

<body ng-app="realty_app" ng-controller="main">
	<!-- Здесь пишем код -->
<div class="nav top_style">
	<div class="container">
			<img src="img/logo.jpg" alt="logotype">
			<h1>{{mainObj.header.slogan}}</h1>
			<div class="lang">
				<div class="lang_wrap">
					<div class="ru lang_elem" ng-click="lang.setLang('rus')">RU</div>
					<div class="en lang_elem" ng-click="lang.setLang('eng')">EN</div>
				</div>
			</div>
			<div class="numbers">
				<h3>8 (777) <span>123-45-67</span></h3>
				<h4 ng-click="feedback.open(mainObj.form.headers.header3)"><span>{{mainObj.header.number}}</span></h4>
			</div>
			<nav>
				<a href="#main">{{mainObj.header.menu1}}</a>
				<a href="#clients">{{mainObj.header.menu2}}</a>
				<a href="#catalog">{{mainObj.header.menu3}}</a>
				<a href="#recomend">{{mainObj.header.menu4}}</a>
				<a href="#service">{{mainObj.header.menu5}}</a>
				<a href="#sotr">{{mainObj.header.menu6}}</a>
				<a href="#advise">{{mainObj.header.menu7}}</a>
				<a href="#contact">{{mainObj.header.menu8}}</a>
			</nav>
	</div>
</div>

<section id="main">
	<a name="main"></a>
	<img src="img/UARk_logo.png" alt="UARC_logo">
	<div class="container">
		<div class="wrap_button"><div class="button_main button_watch"><span>{{mainObj.mainPage.mainButton}}</span></div></div>
		<h4>{{mainObj.mainPage.header}}</h4>
		<div class="navigation_button">
			<a href="#catalog">{{mainObj.mainPage.button1}}</a>
			<a href="#catalog">{{mainObj.mainPage.button2}}</a>
			<a href="#sotr">{{mainObj.mainPage.button3}}</a>
			<a href="#sotr">{{mainObj.mainPage.button4}}</a>
		</div>
	</div>
</section>

<section id="spec">
	<header><h2>{{mainObj.specPage.header}}</h2></header>
	<div class="container">
		<div class="spec_block">
			<div ng-repeat="specs in spec" class="spec_block_mod">
				<div class="sticker_wrap">
					<div class="sticker_blue">
						<div class="triangle"></div>
						<span>{{mainObj.specPage.sale}}</span>
					</div>
				</div>
				<div class="wrap_thumb"><img src="img/test_spec.jpg" alt=""></div>
				<h3>Empire State Building</h3>
				<p>С другой стороны укрепление и развитие структуры требуют от нас анализа условий активизации. </p>
				<ul>
					<li><span>{{mainObj.specPage.floor}}:</span> 3</li>
					<li><span>{{mainObj.specPage.square}}:</span> 143м<sup>2</sup></li>
					<li><span>{{mainObj.specPage.price}}:</span> 24 345 000 ₸</li>
				</ul>
				<div class="read_more">{{mainObj.specPage.more}}</div>
			</div>
		</div>
	</div>
</section>

<section id="clients">
	<a name="clients"></a>
	<h2>{{mainObj.clientPage.header}}</h2>
	<div class="container">
		<div class="clients_block">
			<div ng-repeat="partners in partner" class="clients_elem">
				<h3>Компания «Smart Energy»</h3>
				<div class="img_wrap">
					<img src="img/logos/boinc.jpg" alt="">
				</div>
			</div>
		</div>
	</div>
</section>

<section id="catalog" ng-controller="sliderDemoCtrl">
	<a name="catalog"></a>
	<h2>{{mainObj.catalogPage.header}}</h2>
	<div class="container">
		<div class="configure">
			<div class="left_block">
				<div class="wrap_1">
					<div class="drop_down">
						<header><span>{{dropDown1FilterView}}</span></header>
						<div class="list_block">
							<div class="list_elem" ng-click="changeValueFilter('Все', 1)">{{mainObj.catalogPage.menu1_3}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Купить', 1)">{{mainObj.catalogPage.menu1_1}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Снять в аренду', 1)">{{mainObj.catalogPage.menu1_2}}</div>
						</div>
					</div>
				</div>	
				<div class="wrap_2">
					<div class="drop_down">
						<header><span>{{dropDown2FilterView}}</span></header>
						<div class="list_block">
							<div class="list_elem" ng-click="changeValueFilter('Все', 2)">{{mainObj.catalogPage.menu1_3}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Квартира', 2)">{{mainObj.catalogPage.menu2_1}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Дом', 2)">{{mainObj.catalogPage.menu2_2}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Офис', 2)">{{mainObj.catalogPage.menu2_3}}</div>
							<div class="list_elem" ng-click="changeValueFilter('Земельный участок', 2)">{{mainObj.catalogPage.menu2_4}}</div>
						</div>
					</div>
				</div>	
				<div class="wrap_3">
					<div class="drop_down">
						<header><span>{{dropDown3FilterView}}</span></header>
						<div class="list_block">
							<div class="list_elem" ng-click="changeValueFilter('Все', 3)">{{mainObj.catalogPage.menu3_1}}</div>
							<div class="list_elem" ng-click="changeValueFilter('1-а комнатные', 3)">{{mainObj.catalogPage.menu3_2}}</div>
							<div class="list_elem" ng-click="changeValueFilter('2-х комнатные', 3)">{{mainObj.catalogPage.menu3_3}}</div>
							<div class="list_elem" ng-click="changeValueFilter('3-х комнатные', 3)">{{mainObj.catalogPage.menu3_4}}</div>
						</div>
					</div>
				</div>
			</div>
			<div class="right_block">
				<h5>{{mainObj.specPage.square}}</h5>
                <div class="sliderExample">
                    <div ui-slider="{range: true}" min="0" max="{{sliderMax}}" step="1" use-decimals ng-model="sliderExample9"></div>
                    <input id="sliderFrom" type="text" ng-model="sliderExample9[0]"><input id="sliderTo" type="text" ng-model="sliderExample9[1]" class="second">
                </div>
                <h5 class="second">{{mainObj.specPage.price}}</h5>
                <div class="price">
                	<input type="text" placeholder="{{mainObj.catalogPage.from}}" ng-model="price[0]">
                	<div class="line"></div>
                	<input type="text" placeholder="{{mainObj.catalogPage.to}}" ng-model="price[1]">
                	<div id="tenge" class="val active" ng-click="coefChange('#tenge', 1, 'тг')">₸</div>
                	<div id="dollar" class="val" ng-click="coefChange('#dollar', coef.coef_dol, '$')">$</div>
                </div>
			</div>
		</div>
		<div class="search_result">
			<header class="main"><span>{{mainObj.catalogPage.search}}:</span> {{catalog_search.length}} {{mainObj.catalogPage.search_content}}</header>
			<div class="content_seach">
				<article ng-repeat="stack in catalog_search | filter:typeView | filter:type | filter:quantityRoom | filter:squareRange | filter:priceRange">
					<header>{{stack.name}}</header>
					<div class="{{stack.length}}"></div>
					<div class="wrap_img"><img ng-src="{{stack.thumbnail}}"></div>
					<div class="info">
						<ul>
							<li><span>{{mainObj.specPage.floor}}:</span> {{stack.floor}}</li>
							<li><span>{{mainObj.specPage.square}}:</span> {{stack.square}} м<sup>2</sup></li>
							<li><span>{{mainObj.specPage.price}}:</span> {{ (stack.price / coef.active).toFixed() + ' ' + coef.cur}}</li>
						</ul>
						<button ng-click="info.change($index, true)">{{mainObj.specPage.more}}</button>
					</div>		
				</article>
			</div>
		</div>
	</div>
</section>

<section id="qual">
	<h2>{{mainObj.qualityPage.header}}</h2>
	<div class="container">
		<div class="first_column">
			<div class="icon_elem">
				<div class="icon icon_1"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons1.header}}</h3>
					<p>{{mainObj.qualityPage.icons1.content}}</p>
				</div>
			</div>
			<div class="icon_elem icon_elem_margin">
				<div class="icon icon_2"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons2.header}}</h3>
					<p>{{mainObj.qualityPage.icons2.content}}</p>
				</div>
			</div>
			<div class="icon_elem icon_elem_margin">
				<div class="icon icon_3"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons3.header}}</h3>
					<p>{{mainObj.qualityPage.icons3.content}}</p>
				</div>
			</div>
		</div>
		<div class="second_column">
			<div class="icon_elem">
				<div class="icon icon_4"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons4.header}}</h3>
					<p>{{mainObj.qualityPage.icons4.content}} <br>
						{{mainObj.qualityPage.icons4.content2}}</p>
				</div>
			</div>
			<div class="icon_elem icon_elem_margin_2">
				<div class="icon icon_5"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons5.header}}</h3>
					<p>{{mainObj.qualityPage.icons5.content}}<br>
						{{mainObj.qualityPage.icons5.content2}}</p>
				</div>
			</div>
			<div class="icon_elem icon_elem_margin_2">
				<div class="icon icon_6"></div>
				<div class="text">
					<h3>{{mainObj.qualityPage.icons6.header}}</h3>
					<p>{{mainObj.qualityPage.icons6.content}}<br>
						{{mainObj.qualityPage.icons6.content2}}<br>
						{{mainObj.qualityPage.icons6.content3}}</p>
				</div>
			</div>
		</div>
		<div class="third_column">
			<form action="">
				<h4>{{mainObj.form.headers.header1}} <br> <span>{{mainObj.form.headers.header2}}</span></h4>
				<input type="text" placeholder="{{mainObj.form.placeholders.name}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.telephone}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.mail}}">
				<button>Отправить</button>
			</form>
		</div>
	</div>
</section>

<section id="recom">
	<a name="recomend"></a>
	<h2>{{mainObj.recomendPage.header}}</h2>
	<div class="container">
		<p class="main">{{mainObj.recomendPage.main_content_part1}} <span>Smart Realtor</span> {{mainObj.recomendPage.main_content_part2}}</p>
		<div class="first_column">
			<h3>{{mainObj.recomendPage.header_director}}</h3>
			<div class="wrap_img"><img src="img/example._video.jpg" alt=""></div>
			<p>{{mainObj.recomendPage.content}}</p>
		</div>
		<div class="second_column">
			<h3>{{mainObj.recomendPage.header_clients}}</h3>
			<div class="reviews">
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
				<div class="wrap_rev"><img src="img/example._rev.jpg" alt=""></div>
			</div>
		</div>
	</div>
</section>

<section id="service">
	<a name="service"></a>
	<h2>{{mainObj.servicePage.header}}</h2>
	<div class="container">
		<img src="img/background/service.png" alt="background">
		<div class="handy">
			<img src="img/handy_logo.png" alt="">
			<p>— {{mainObj.servicePage.subHeader}}<span>Smart Realtor</span></p>
		</div>
		<div class="info">
			<h3>{{mainObj.servicePage.listHeader}}</h3>
			<div class="wrap">
				<ul class="column_first">
					<li>{{mainObj.servicePage.listElem1}}</li>
					<li>{{mainObj.servicePage.listElem2}}</li>
					<li>{{mainObj.servicePage.listElem3}}</li>
					<li>{{mainObj.servicePage.listElem4}}</li>
					<li>{{mainObj.servicePage.listElem5}}</li>
					<li>{{mainObj.servicePage.listElem6}}</li>
					<li>{{mainObj.servicePage.listElem7}}</li>
				</ul>
				<ul class="column_second">
					<li>{{mainObj.servicePage.listElem8}}</li>
					<li>{{mainObj.servicePage.listElem9}}</li>
					<li>{{mainObj.servicePage.listElem10}}</li>
					<li>{{mainObj.servicePage.listElem11}}</li>
					<li>{{mainObj.servicePage.listElem12}}</li>
					<li>{{mainObj.servicePage.listElem13}}</li>
					<li>{{mainObj.servicePage.listElem14}}</li>
					<li>{{mainObj.servicePage.listElem15}}</li>
				</ul>
			</div>
			<p>{{mainObj.servicePage.sloganTop}}<br><span>{{mainObj.servicePage.sloganBot}}</span></p>
			<h4><span class="adress">+7 (701) <span>123-45-67</span></span> <a href="fix@smartrealty.kz">fix@smartrealty.kz</a></h4>
			<form action="">
				<h3>{{mainObj.form.headers.header3}}</h3>
				<input type="text" placeholder="{{mainObj.form.placeholders.name}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.telephone}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.mail}}">
				<button>{{mainObj.form.placeholders.send}}</button>
			</form>
			<h4 class="slogan">
				{{mainObj.servicePage.wordSlogan1}}<br> 
				{{mainObj.servicePage.wordSlogan2}} <br> 
				<span>{{mainObj.servicePage.wordSlogan3}}</span>
			</h4>
		</div>
	</div>
</section>

<section id="sotr">
	<a name="sotr"></a>
	<h2>{{mainObj.sotrPage.header}}</h2>
	<div class="container">
		<div class="first_column">
			<h3>{{mainObj.sotrPage.subHeader}}</h3>
			<p>{{mainObj.sotrPage.content1}}</p>
			<p>{{mainObj.sotrPage.content2}}</p>
			<p>{{mainObj.sotrPage.content3}}</p>
		</div>
		<div class="second_column">
			<div class="wrapper">
				<h4>{{mainObj.sotrPage.planeHeader1}} <br> 
					<span class="bold">{{mainObj.sotrPage.planeHeader2}}</span> 
					<span class="and">{{mainObj.sotrPage.planeHeader3}}</span> 
					<span class="thin" >{{mainObj.sotrPage.planeHeader4}}</span>
				</h4>
				<div class="icon"></div>
				<div class="wrap_button"><div class="button_main" ng-click="feedback.open(mainObj.form.headers.header3)"><span>{{mainObj.sotrPage.button}}</span></div></div>
			</div>
		</div>
	</div>
</section>

<section id="advise">
	<a name="advise"></a>
	<h2>{{mainObj.bonus.header}}</h2>
	<div class="container">
		<div class="first_column">
			<p class="text">{{mainObj.bonus.content1}}</p>
			<p class="text">{{mainObj.bonus.content2}}</p>
			<img src="img/confetti.png" alt="confeti">
			<p class="label" ng-click="feedback.open(mainObj.form.headers.header4)"><span  class="second">{{mainObj.bonus.button1}} <br></span> <span  class="third">{{mainObj.bonus.button2}}</span></p>
		</div>
		<div class="second_colimn">
			<div class="wrap">
				<img src="img/skid.jpg">
			</div>
		</div>
	</div>
</section>

<div id="map">
	<a name="contact"></a>
	<div id="map_canvas"></div>
	<div class="first_column">
		<div class="wrap">
			<h3>{{mainObj.contacts.adress1}} <br> {{mainObj.contacts.adress2}}</h3>
			<h4>8 (800) <span>123-45-67</span></h4>
			<h5>9:00 - 19:00 — Cб-Вс 10:00 - 15:00 </h5>
			<button ng-click="feedback.open(mainObj.form.headers.header3)">{{mainObj.contacts.button}}</button>
			<div class="social">
				<div class="icon_social icon_social_1"></div>
				<div class="icon_social icon_social_2"></div>
				<div class="icon_social icon_social_3"></div>
				<div class="icon_social icon_social_4"></div>
				<div class="icon_social icon_social_5"></div>
			</div>
		</div>	
	</div>
</div>

<footer>
	<div class="container">
		<h3>© «Smart-Realtor» — 2016</h3>
		<img src="img/mind_logo.png" alt="">
	</div>
</footer>

<!-- Модальные окна -->
<div ng-if="auth.show" class="auth modal">
	<div class="wrap">
		<div class="window">
			<div class="closer" ng-click="auth.close()"></div>
			<h3>Авторизация</h3>
			<form action="">
				<input type="text"><input type="text">
				<button>ВОЙТИ</button>
				<div class="reg">Регистрация</div>
				<h4>Для получения доступа вам необходимо авторизоватся</h4>
			</form>
		</div>
	</div>
	<div class="wrap">
		<div class="window">
			<div class="closer" ng-click="auth.close()"></div>
			<?php custom_registration_function(); ?>
		</div>
	</div>
</div>

<div ng-if="lang.show" class="lang modal">
	<div class="wrap">
		<div class="window">
			<h3>Выберите язык</h3>
			<div class="language">
				<div class="rus" ng-click="lang.setLang('rus')">
					<div class="icon_lan"></div>
					<div class="but">Русский</div>
				</div>
				<div class="eng" ng-click="lang.setLang('eng')">
					<div class="icon_lan"></div>
					<div class="but">English</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div ng-if="info.show" class="info modal">
	<div class="wrap">
		<div class="window">
			<div class="closer" ng-click="info.close()"></div>
			<div class="column_first">
				<a class="fancybox first" rel="gallery1" href="{{info.thumbnail}}">
					<img class="first" ng-src="{{info.thumbnail}}">
				</a>
				<div class="lenta">
					<a ng-repeat="image in info.images" class="fancybox {{ $index == 2 ? 'last' : ''}}" rel="gallery1" href="{{info.images[$index]}}" >
						<img ng-src="{{info.images[$index]}}">
					</a>
				</div>	
				<div class="manager">
					<h3>{{mainObj.modal.manager}}</h3>
					<div class="photo_wrap">
						<img ng-src="{{info.author.image}}" alt="">
					</div>
					<div class="info">
						<h4>{{info.author.name}}</h4>
						<h5>{{info.author.telephone}}</h5>
					</div>
				</div>			
			</div>
			<div class="second_column">
				<h4>{{info.name}}</h4>
				<ul>
					<li><span>{{mainObj.specPage.floor}}:</span> {{info.floor}}</li>
					<li><span>{{mainObj.specPage.square}}:</span> {{info.square}} м<sup>2</sup></li>
					<li class="last"><span>{{mainObj.specPage.price}}:</span> {{ (info.price / coef.active).toFixed() + ' ' + coef.cur}}</li>
				</ul>
				<p>{{info.content}}</p>
				<form action="">
					<h5>Обратная связь</h5>
					<div class="column_first">
						<input type="text" placeholder="{{mainObj.form.placeholders.name}}">
						<input type="text" placeholder="{{mainObj.form.placeholders.telephone}}">
						<input type="text" placeholder="{{mainObj.form.placeholders.mail}}">
					</div>
					<textarea name="" id="" cols="30" rows="5" placeholder="Комментарии"></textarea>
					<button>Отправить</button>
				</form>
			</div>
			<div class="share_button">
				<div class="facebook"></div>
				<div class="vk"></div>
				<div class="linkedin"></div>
				<div class="twitter"></div>
			</div>
		</div>
	</div>
</div>

<div ng-if="feedback.show" class="auth modal feedback">
	<div class="wrap">
		<div class="window">
			<div class="closer" ng-click="feedback.close()"></div>
			<h3>{{feedback.header}}</h3>
			<form action="">
				<input type="text" placeholder="{{mainObj.form.placeholders.name}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.telephone}}">
				<input type="text" placeholder="{{mainObj.form.placeholders.mail}}">
				<button>{{mainObj.form.placeholders.send}}</button>
				<h4>{{mainObj.form.placeholders.feed}}</h4>
			</form>
		</div>
	</div>
</div>
<!--     Пример формы обратной связи          -->
<!-- 	<div class="main">
      <h3>Внимание</h3>
      <p>Оставьте ваши контактные данные и наш консультант<br/>свяжется с вами в течении 30 секунд</p>

		<form id="application" action="mail.php" method="POST" name=" application ">
			<input name="name" id="applicationName" maxlength="20" placeholder="Введите ваше имя" required />
			<input name="email" type="email" id="applicationEmail" maxlength="20" placeholder="Введите ваш E-mail" required/>
			<input name="telephone" type="Tel" id="applicationTelephone" maxlength="20" placeholder="Введите ваш телефон" required />
			<input type="submit">
			<div id="app"> Отправить </div>
		</form>
	</div>
	<div id="mail" class="not_visible_mail"></div> -->



	<!--[if lt IE 9]>
	<script src="bower_components/html5shiv/es5-shim.min.js"></script>
	<script src="bower_components/html5shiv/html5shiv.min.js"></script>
	<script src="bower_components/html5shiv/html5shiv-printshiv.min.js"></script>
	<script src="bower_components/respond/respond.min.js"></script>
	<![endif]-->


	<!-- with CDN -->
	<script src="http://maps.google.com/maps/api/js?sensor=false"></script>

	<!-- local -->
	<script src="bower_components/fancybox/source/jquery.fancybox.pack.js"></script>
	<script src="bower_components/nav/nav.js"></script>
	<script src="js/common.js"></script>
	<script src="js/slider.js"></script>
</body>
</html>